package com.web.creator.controller;

public class Sector {

}

package com.web.creator.service;

public interface SectorService {

}

package com.web.creator.service;

import java.util.List;

import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.RegisterDto;

public interface RegsiterService {

	ResponseDto registerUser(RegisterDto dto);

	RegisterDto getUserRegDetailsById(String userId);

	List<RegisterDto> getAllRegUserDetails();

	ResponseDto deleteUserById(String userId);
	
	

	

	

}

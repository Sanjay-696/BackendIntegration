package com.web.creator.service;

import java.util.List;

import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.TemplateDto;

public interface TemplateService {

	ResponseDto createAndUpdateTemplate(TemplateDto dto);

	List<TemplateDto>  getTemplates();

	TemplateDto getTemplateById(String tempId);

	ResponseDto deleteTemplateById(String tempId);


}

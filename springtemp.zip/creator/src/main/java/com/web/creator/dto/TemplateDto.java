package com.web.creator.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TemplateDto {
	
	private String tempId;
	
	private String tempName;
	
	private String logoUrl;
	
	private Long sectorId;
		
	private String fontFamily;

	private String fontColor;
	
	private String headerElement;
	
	private String bodyElement;
	
	private String footerElement;

}

package com.web.creator.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SectorDto {
	
	private Long id;
	private String sectorName;
	private String headerElement;
	private String bodyElement ;
	private String footerElement;
}

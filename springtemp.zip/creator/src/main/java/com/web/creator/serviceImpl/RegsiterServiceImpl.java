package com.web.creator.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.creator.dao.RegisterRepository;
import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.RegisterDto;
import com.web.creator.entity.RegisterEntity;
import com.web.creator.service.RegsiterService;

@Service
public class RegsiterServiceImpl implements RegsiterService {

	@Autowired
	private RegisterRepository userRepository;

	@Override
	public ResponseDto registerUser(RegisterDto dto) {

		ResponseDto response = new ResponseDto();

		try {

			RegisterEntity user=new RegisterEntity();
			if (dto.getUserId() != null) {

				Optional<RegisterEntity> userOpt = userRepository.findById(dto.getUserId());
				if (!userOpt.isEmpty()) {
					user=userOpt.get();
					user.setUserName(dto.getUserName());
					user.setEmail(dto.getEmail());
					user.setPassword(dto.getPassword());
					user.setPhoneNumber(dto.getPhoneNumber());
					
				}
			} else {

				user.setUserName(dto.getUserName());
				user.setEmail(dto.getEmail());
				user.setPassword(dto.getPassword());
				user.setPhoneNumber(dto.getPhoneNumber());
			}

			userRepository.save(user);
			response.setMessage("SUCCESS");

		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}

		return response;
	}

	@Override
	public RegisterDto getUserRegDetailsById(String userId) {
		RegisterDto dto = new RegisterDto();
		Optional<RegisterEntity> userOpt = userRepository.findById(userId);
		if (!userOpt.isEmpty()) {

			RegisterEntity user = userOpt.get();

			dto.setUserName(user.getUserName());
			dto.setEmail(user.getEmail());
			dto.setPassword(user.getPassword());
			dto.setPhoneNumber(user.getPhoneNumber());
			

		}
		return dto;
	}

	@Override
	public List<RegisterDto> getAllRegUserDetails() {
		try {
			List<RegisterEntity> list=userRepository.findAll();
			
			List<RegisterDto> dtoList=new ArrayList<RegisterDto>();
			
			list.forEach(details->{
				RegisterDto dto=new RegisterDto();
				
				dto.setUserId(details.getUserId());
				dto.setUserName(details.getUserName());
				dto.setEmail(details.getEmail());
				dto.setPassword(details.getPassword());
				dto.setPhoneNumber(details.getPhoneNumber());
				dtoList.add(dto);
			});
			return dtoList;
		
		} catch (Exception e) {
			throw e;
		}
		
	}

	@Override
	public ResponseDto deleteUserById(String userId) {
		ResponseDto response=new ResponseDto();
		try {
			if(userRepository.existsById(userId))
			{
				userRepository.deleteById(userId);
				response.setMessage("DELETED SUCCESSFULLY");
				return response;
			}
			response.setMessage("USERID NOT FOUND");
		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}
		return response;
	}
	
	}

	

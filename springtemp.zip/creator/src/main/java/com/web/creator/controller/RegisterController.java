package com.web.creator.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.RegisterDto;
import com.web.creator.service.RegsiterService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class RegisterController {

	
	private final RegsiterService authService;

   
	
	@PostMapping("/register")
	public ResponseEntity<ResponseDto> registerUser(@RequestBody RegisterDto dto)
	{
		return ResponseEntity.ok(authService.registerUser(dto));
	}
	

	@GetMapping("/register/{userId}")
	public ResponseEntity<RegisterDto> getUserRegDetailsById(@PathVariable("userId") String userId) {
		return ResponseEntity.ok(authService.getUserRegDetailsById(userId));
	}
	
	@GetMapping("/register")
	public ResponseEntity<List<RegisterDto>> getAllRegUserDetails()
	{
		return ResponseEntity.ok(authService.getAllRegUserDetails());
	}
	
	@DeleteMapping("/register/{userId}")
	public ResponseEntity<ResponseDto> deleteUserById(@RequestParam("userId") String userId)
	{
		return ResponseEntity.ok(authService.deleteUserById(userId));
	}
}

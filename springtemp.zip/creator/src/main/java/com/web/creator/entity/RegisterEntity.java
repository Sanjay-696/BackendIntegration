package com.web.creator.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="Users")
@Data
public class RegisterEntity {
 	
	@Id
	@UuidGenerator
	@Column(name="user_id ")
    private String userId;
	
	@Column(name="user_name")
	private String userName;
	
	private String email;
	
	@Column(name="user_password")
	private String password;
	
	@Column(name="phone_number")
	private String phoneNumber;

}

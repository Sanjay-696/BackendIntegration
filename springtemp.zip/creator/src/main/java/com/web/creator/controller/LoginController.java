package com.web.creator.controller;


import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.web.creator.dto.LoginDto;
import com.web.creator.dto.ResponseDto;
import com.web.creator.service.LoginService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("loginapi")
@RequiredArgsConstructor
public class LoginController {
	
	private final LoginService loginService;

	@PostMapping("/login")
	public ResponseEntity<ResponseDto> authenticateAndSave(@RequestBody LoginDto dto)
	{
		return ResponseEntity.ok(loginService.authenticateAndSave(dto));
	}
	
	@GetMapping("/login")
	public ResponseEntity<List<LoginDto>> getAllLoginUsers()
	{
		return ResponseEntity.ok(loginService.getAllLoginUsers());
	}
}


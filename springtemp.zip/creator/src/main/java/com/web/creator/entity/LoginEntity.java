package com.web.creator.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;


@Entity
@Table(name="login")
@Data

public class LoginEntity {
	@Id
	@UuidGenerator
	@Column(name="login_id")
	private String loginId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="userId")
	private RegisterEntity userId;

	@Column(name="user_name")
	private String userName;
	
	@Column(name="")
	private String userPassword;

}

package com.web.creator.serviceImpl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.web.creator.dao.LoginRepository;
import com.web.creator.dao.RegisterRepository;
import com.web.creator.dto.LoginDto;
import com.web.creator.dto.ResponseDto;
import com.web.creator.entity.LoginEntity;
import com.web.creator.entity.RegisterEntity;
import com.web.creator.service.LoginService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {
	
	private final LoginRepository loginRepository;

	private final RegisterRepository registerRepository;


	@Override
	public ResponseDto authenticateAndSave(LoginDto dto) {
		ResponseDto res=new ResponseDto();
		try {
		RegisterEntity regEnt=registerRepository.findByUserName(dto.getUserName());
		if(regEnt!=null&& regEnt.getPassword().equals(dto.getUserPassword()))
		{
				LoginEntity logEnt=new LoginEntity();
				logEnt.setUserName(regEnt.getUserName());
				logEnt.setUserPassword(regEnt.getPassword());
				logEnt.setUserId(regEnt);
				
				LoginEntity saved=loginRepository.save(logEnt);
				
		
				LoginDto logDto=new LoginDto();
				logDto.setLoginId(saved.getLoginId());
//				logDto.setUserId(saved);
				logDto.setUserName(saved.getUserName());
				logDto.setUserPassword(saved.getUserPassword());
				res.setMessage("Login Successfully");
				res.setStatuscode("200");
			}
			else
			{
				res.setMessage("Inavlid Credentials");
				res.setStatuscode("400");
			}
			
		}catch (Exception e) {
			res.setMessage("User Not Found");
			res.setStatuscode("404");
			throw e;
		}
			return res;
		}


	@Override
	public List<LoginDto> getAllLoginUsers() {
		try {
			List<LoginEntity> list=loginRepository.findAll();
			List<LoginDto> dtolist=new ArrayList<LoginDto>();
			
			list.forEach(details->{
				LoginDto dto=new LoginDto();
				dto.setLoginId(details.getLoginId());
				dto.setUserId(details.getUserId());
				dto.setUserName(details.getUserName());
				dto.setUserPassword(details.getUserPassword());
				dtolist.add(dto);
			});
			return dtolist;
			
		} catch (Exception e) {
			throw e;
		}
		
	}
}

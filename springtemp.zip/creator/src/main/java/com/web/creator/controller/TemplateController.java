package com.web.creator.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.TemplateDto;
import com.web.creator.service.TemplateService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("tempapi")
@RequiredArgsConstructor
public class TemplateController {
	
	private final TemplateService templateService;
	
	@PostMapping("/template")
	public ResponseEntity<ResponseDto> createAndUpdateTemplate(@RequestBody TemplateDto dto)
	{
		return ResponseEntity.ok(templateService.createAndUpdateTemplate(dto));
	}
	
	@GetMapping("/template")
	public ResponseEntity<List<TemplateDto>> getTemplates()
	{
		return ResponseEntity.ok(templateService.getTemplates());
	}
	
	@GetMapping("/template/{tempId}")
	public ResponseEntity<TemplateDto> getTemplateById(@PathVariable("tempId") String tempId)
	{
		return ResponseEntity.ok(templateService.getTemplateById(tempId));
	}
	
	@DeleteMapping("/template/{tempId}")
	public ResponseEntity<ResponseDto> deleteTemplateById(@RequestParam("tempId") String tempId)
	{
		return ResponseEntity.ok(templateService.deleteTemplateById(tempId));
	}
	

}

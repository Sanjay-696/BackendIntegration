package com.web.creator.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.web.creator.entity.LoginEntity;

public interface LoginRepository extends JpaRepository<LoginEntity, String> {

	
}

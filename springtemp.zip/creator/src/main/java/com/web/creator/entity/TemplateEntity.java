package com.web.creator.entity;

import org.hibernate.annotations.UuidGenerator;

import com.web.creator.controller.Sector;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="templates")
@Data
public class TemplateEntity {
	
	@Id
	@UuidGenerator
	@Column(name="temp_id")
    private String tempId;
	
	@Column(name="temp_name")
	private String tempName;
	
	@Column(name="logo_url")
	private String logoUrl;
	
	@Column(name="font_family")
	private String fontFamily;
	
	@Column(name="font_color")
	private String fontColor;
	

	@Column(name="header_element")
	private String headerElement;
	
	@Column(name="body_element")
	private String bodyElement;
	

	@Column(name="footer_element")
	private String footerElement;
	
	@ManyToOne
	@JoinColumn(name="sector_Id",referencedColumnName = "id")
	private Sector sector;


}

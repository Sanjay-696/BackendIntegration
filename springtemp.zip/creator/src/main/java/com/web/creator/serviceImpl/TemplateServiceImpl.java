	package com.web.creator.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.web.creator.dao.TemplateRepository;

import com.web.creator.dto.ResponseDto;
import com.web.creator.dto.TemplateDto;

import com.web.creator.entity.TemplateEntity;

import com.web.creator.service.TemplateService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TemplateServiceImpl implements TemplateService {

	
	private final TemplateRepository templateRepository;
	
	@Override
	public ResponseDto createAndUpdateTemplate(TemplateDto dto) {

			ResponseDto response = new ResponseDto();
			try {
				TemplateEntity temp=new TemplateEntity();
				if(dto.getTempId()!=null)
				{
					Optional<TemplateEntity> tempOpt=templateRepository.findById(dto.getTempId());
					if(!tempOpt.isEmpty())
					{
						temp=tempOpt.get();
						temp.setTempName(dto.getTempName());
						temp.setSectorName(dto.getSectorId());
						temp.setLogoUrl(dto.getLogoUrl());
						temp.setFontFamily(dto.getFontFamily());
						temp.setFontColor(dto.getFontColor());
						temp.setHeaderElement(dto.getHeaderElement());
						temp.setBodyElement(dto.getBodyElement());
					    temp.setFooterElement(dto.getFooterElement());
					}
				}
				else
				{
					temp.setTempName(dto.getTempName());
					temp.setSectorName(dto.getSectorId());
					temp.setLogoUrl(dto.getLogoUrl());
					temp.setFontFamily(dto.getFontFamily());
					temp.setFontColor(dto.getFontColor());
					temp.setHeaderElement(dto.getHeaderElement());
					temp.setBodyElement(dto.getBodyElement());
				    temp.setFooterElement(dto.getFooterElement());
				    response.setMessage("TEMPLATE UPDATED SUCCESSFULLY");
				    response.setStatuscode("200");
				}
				templateRepository.save(temp);
				response.setMessage("TEMPLATE CREATED SUCCESSFULLY");
				response.setStatuscode("200");
			} catch (Exception e) {
				response.setMessage("TEMPLATE ALDREADY EXISTS");
				response.setStatuscode("404");
				throw e;
			}

			return response;		
	}

	@Override
	public List<TemplateDto> getTemplates() {
		TemplateDto dto=new TemplateDto();
		try {
			List<TemplateEntity> list=templateRepository.findAll();
			List<TemplateDto> dtolist=new ArrayList<TemplateDto>();
			
			list.forEach(details->{
				dto.setTempId(details.getTempId());
				dto.setTempName(details.getTempName());
				dto.setSectorName(details.getSectorName());
				dto.setLogoUrl(details.getLogoUrl());
				dto.setFontFamily(details.getFontFamily());
				dto.setFontColor(details.getFontColor());
				dto.setHeaderElement(details.getHeaderElement());
				dto.setBodyElement(details.getBodyElement());
				dto.setFooterElement(details.getFooterElement());
				dtolist.add(dto);
			});
			return dtolist;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public TemplateDto getTemplateById(String tempId) {
		TemplateDto dto=new TemplateDto();
		Optional<TemplateEntity> tempOpt= templateRepository.findById(tempId);
		if(!tempOpt.isEmpty())
		{
			TemplateEntity temp=new TemplateEntity();
			temp=tempOpt.get();
			dto.setTempName(temp.getTempName());
			dto.setSectorName(temp.getSectorName());
			dto.setHeaderElement(temp.getHeaderElement());
			dto.setBodyElement(temp.getBodyElement());
			dto.setFooterElement(temp.getFooterElement());
		}
		return dto;
	}

	@Override
	public ResponseDto deleteTemplateById(String tempId) {
		ResponseDto response=new ResponseDto();
		try {
			if(templateRepository.existsById(tempId))
			{
				templateRepository.deleteById(tempId);
				response.setMessage("DELETED SUCCESSFULLY");
				return response;
			}
			response.setMessage("USERID NOT FOUND");
		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}
		return response;
	}
}
	

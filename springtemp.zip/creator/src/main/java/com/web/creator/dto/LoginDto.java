package com.web.creator.dto;


import com.web.creator.entity.RegisterEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginDto {

private String loginId;

private RegisterEntity userId;

private String userName;

private String userPassword; 

}

package com.web.creator.service;

import java.util.List;

import com.web.creator.dto.LoginDto;
import com.web.creator.dto.ResponseDto;
public interface LoginService {

	ResponseDto authenticateAndSave(LoginDto dto);

	List<LoginDto> getAllLoginUsers();
}

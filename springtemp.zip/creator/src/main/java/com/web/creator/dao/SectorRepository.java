package com.web.creator.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.web.creator.entity.SectorEntity;

public interface SectorRepository extends JpaRepository<SectorEntity,Long> {

}

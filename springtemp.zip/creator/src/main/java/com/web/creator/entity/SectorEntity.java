package com.web.creator.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Table(name="sectors")
@Data
public class SectorEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@Column(name="sector_name")
	private String sectorName;
	
	@Column(name="header_element")
	private String headerElement;
	
	@Column(name="body_element")
	private String bodyElement;
	
	@Column(name="footer_element")
	private String footerElement;


}

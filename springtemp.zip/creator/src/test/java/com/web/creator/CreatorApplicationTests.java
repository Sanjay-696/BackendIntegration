package com.web.creator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreatorApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.project.ecommerce.service;

public interface ProductService {

}

package com.project.ecommerce.entity;

public class ProductEntity {

}

package com.project.ecommerce.dao;

public interface ProductRepository {

}

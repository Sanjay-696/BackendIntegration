package com.project.ecommerce.entity;



import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="customer")
@Data
public class CustomerEntity {
	@Id
	@UuidGenerator
	@Column(name="customer_id")
	private String customerId;
	
	@Column(name="	customer_name")
	private String customerName;
	
	@Column(name="mobile_number")
	private String mobileNumber;
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
}

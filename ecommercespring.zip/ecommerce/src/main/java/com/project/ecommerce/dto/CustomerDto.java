package com.project.ecommerce.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;



@Data

@NoArgsConstructor
@AllArgsConstructor
public class CustomerDto {

    private String customerId;         

    private String customerName;        

    private String mobileNumber;       

    private String email;              

    private String address;
}

package com.project.ecommerce.dto;

public class ProductDto {

}

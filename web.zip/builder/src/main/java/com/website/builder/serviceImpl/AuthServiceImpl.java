package com.website.builder.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.website.builder.dao.UserRepository;
import com.website.builder.dto.ResponseDto;
import com.website.builder.dto.UserDto;
import com.website.builder.entity.UserEntity;
import com.website.builder.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public ResponseDto registerUser(UserDto dto) {
	    ResponseDto response = new ResponseDto();

	    try {
	        UserEntity user = new UserEntity();

	        if (dto.getUserId() != null) {
	            Optional<UserEntity> userOpt = userRepository.findById(dto.getUserId());

	            if (!userOpt.isEmpty()) {
	                user = userOpt.get();
	                user.setUserName(dto.getUserName());
	                user.setUserEmail(dto.getUserEmail());
	                user.setUserPassword(dto.getUserPassword());
	                user.setUserPhoneNumber(dto.getUserPhoneNumber());
	            }
	        } else {
	            user.setUserName(dto.getUserName());
	            user.setUserEmail(dto.getUserEmail());
	            user.setUserPassword(dto.getUserPassword());
	            user.setUserPhoneNumber(dto.getUserPhoneNumber());
	        }


	        userRepository.save(user);
	        response.setMessage("USER SUCCESSFULLY REGISTERED");

	    } catch (Exception e) {
	        response.setMessage("FAILURE");
	        throw e;
	    }

	    return response;
	}
	
}


package com.website.builder.service;

import com.website.builder.dto.ResponseDto;
import com.website.builder.dto.UserDto;

public interface AuthService {

	ResponseDto registerUser(UserDto dto);

}

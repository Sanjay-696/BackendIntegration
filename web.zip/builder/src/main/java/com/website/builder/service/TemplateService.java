package com.website.builder.service;

public interface TemplateService {

}

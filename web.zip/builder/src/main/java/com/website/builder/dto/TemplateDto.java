package com.website.builder.dto;

import lombok.Data;

@Data
public class TemplateDto {

	private String tempId;
	
	private String tempName;
	
	private String headerElements;
	
	private String bodyElements;
	
	private String footerElements;

}

package com.website.builder.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="user_authentication")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserEntity {

   @Id
   @UuidGenerator
   @Column(name="user_Id")
   private String userId;
	
   @Column(name="user_Name")
	private String userName;
	
   @Column(name="user_Email")
	private String userEmail;
	
   @Column(name="user_Password")
	private String userPassword;
	
   @Column(name="user_PhoneNumber")
	private String userPhoneNumber; 
}

package com.website.builder.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ResponseDto {

	private String message;
	
	private String statuscode;
}

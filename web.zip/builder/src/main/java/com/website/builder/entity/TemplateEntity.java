package com.website.builder.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name="Templates")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TemplateEntity {
	
	
	@Id
	@Column(name="temp_Id")
	@UuidGenerator
	private String tempId;
	
	@Column(name="temp_Name")
	private String tempName;
	
	@Column(name="header_Elemments")
	private String headerElements;
	
	@Column(name="body_Elements")
	private String bodyElements;
	
	@Column(name="footer_Elements")
	private String footerElements;
}

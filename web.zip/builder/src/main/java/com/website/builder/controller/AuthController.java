package com.website.builder.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.website.builder.dto.ResponseDto;
import com.website.builder.dto.UserDto;
import com.website.builder.service.AuthService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("auth")
@RequiredArgsConstructor
public class AuthController {

	private final AuthService authService;
	
	@PostMapping("/register")
	public ResponseEntity<ResponseDto> registerUser(@RequestBody UserDto dto)
	{
		return ResponseEntity.ok(authService.registerUser(dto));
	}
}

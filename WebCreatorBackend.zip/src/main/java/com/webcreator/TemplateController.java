package com.webcreator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/templates")
public class TemplateController {

    @Autowired
    private TemplateRepository templateRepository;

    @PostMapping("/create")
    public ResponseEntity<?> createTemplate(@RequestBody Template template) {
        return ResponseEntity.ok(templateRepository.save(template));
    }

    @GetMapping("/user/{userId}")
    public List<Template> getUserTemplates(@PathVariable Long userId) {
        return templateRepository.findByOwnerId(userId);
    }
}

package com.buyeasy.dto;

import lombok.Data;

@Data
public class ProductDto {
    private String productId;
    private String productName;
    private Integer quantity;
}
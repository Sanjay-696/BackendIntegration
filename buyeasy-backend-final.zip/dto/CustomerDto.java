package com.buyeasy.dto;

import lombok.Data;

@Data
public class CustomerDto {
    private String customerId;
    private String customerName;
    private String mobileNumber;
    private String email;
    private String address;
}
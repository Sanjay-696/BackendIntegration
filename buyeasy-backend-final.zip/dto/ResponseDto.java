package com.buyeasy.dto;

import lombok.Data;

@Data
public class ResponseDto {
    private String message;
    private String statusCode;
}
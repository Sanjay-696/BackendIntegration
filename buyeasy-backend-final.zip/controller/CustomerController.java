package com.buyeasy.controller;

public class CustomerController {}

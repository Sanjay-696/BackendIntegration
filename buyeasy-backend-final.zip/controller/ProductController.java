package com.buyeasy.controller;

public class ProductController {}

package com.buyeasy.service;

public interface ProductService {}
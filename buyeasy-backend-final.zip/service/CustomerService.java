package com.buyeasy.service;

public interface CustomerService {}
package com.buyeasy.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Entity
@Data
@Table(name="orders")
public class OrderEntity {
    @Id
    private String orderId;

    @ManyToOne
    private CustomerEntity customer;

    @OneToMany(mappedBy="order", cascade=CascadeType.ALL)
    private List<OrderItemEntity> orderItems;
}
package com.buyeasy.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class ProductEntity {
    @Id
    private String productId;
    private String productName;
    private Integer quantity;
}
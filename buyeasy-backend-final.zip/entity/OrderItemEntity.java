package com.buyeasy.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class OrderItemEntity {
    @Id
    private String orderItemId;

    @ManyToOne
    private OrderEntity order;

    @ManyToOne
    private ProductEntity product;

    private Integer quantity;
}
package com.buyeasy.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class CustomerEntity {
    @Id
    private String customerId;
    private String customerName;
    private String mobileNumber;
    private String email;
    private String address;
}
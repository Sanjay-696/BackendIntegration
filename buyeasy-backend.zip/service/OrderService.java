package com.example.buyeasy.service;

import com.example.buyeasy.dto.OrderRequest;
import com.example.buyeasy.entity.Order;
import java.util.List;

public interface OrderService {
    Order placeOrder(OrderRequest orderRequest);
    List<Order> getOrdersByCustomer(Long customerId);
}
package com.example.buyeasy.service;

import com.example.buyeasy.entity.Product;
import java.util.List;

public interface ProductService {
    Product saveProduct(Product product);
    List<Product> getAllProducts();
}